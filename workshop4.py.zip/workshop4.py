class User:
    def __init__(self, name, pin, password):
        self.name = name
        self.pin = pin
        self.password = password

    def change_name(self, name):
        self.name = name

    def change_pin(self, pin):
        self.pin = pin

    def change_password(self, password):
        self.password = password


# user1 = User("Eric", 7891, "Bundles123") (Driver Code for Task 1)
# print(user1.name, user1.pin, user1.password)

# user1 = User("Eric", 7891, "Bundles123") (Driver Code for Task 2)
# print(user1.name, user1.pin, user1.password)
# user1.change_name("Kakashi")
# user1.change_pin(1234)
# user1.change_password("Sensei")
# print(user1.name, user1.pin, user1.password)

class BankUser(User):
    def __init__(self, name, pin, password, balance=0):
        super().__init__(name, pin, password)
        self.balance = balance


# user1 = BankUser("Eric", 7891, "Bundles123") (Driver Code for Task 3)
# print(user1.name, user1.pin, user1.password, user1.balance)


    def show_balance(self):
        print(self.name, "your balance is: ", f"$ {self.balance}")

    def withdraw(self):
        withdraw = int(input("Enter the amount you wish to withdraw: "))
        self.balance -= withdraw

    def deposit(self):
        deposit = int(
            input("Please enter in the amount you wish to deposit: "))
        self.balance += deposit

        # user1 = BankUser("Eric", 7891, "Bundles123")
        # user1.show_balance()
        # user1.deposit()
        # user1.show_balance()
        # user1.withdraw()
        # user1.show_balance()
        # print(user1.show_balance, user1.withdraw, user1.deposit)

    def transfer_money(self):
        user_pin = int(input("Enter your PIN: "))
        if user_pin == self.pin:
            self.balance -= self.balance
            print("Transfer Authorized")
            return True
        else:
            print("Invalid PIN. Transaction canceled.")
            return False

    def request_money(self):
        alt_user_pin = int(input("Authentication Required: "))
        if alt_user_pin == self.pin:
            int(user2.password())
            user1.balance -= user2.balance
            return True
        else:
            return False


user1 = BankUser("Eric", 7891, "Bundles123")
user2 = BankUser("Cire", 1987, "123Bundles")
user2.deposit()
user2.show_balance()
user1.show_balance()
user2.transfer_money()
user2.show_balance()
user1.show_balance()
user2.request_money()
user2.show_balance()
user1.show_balance()
